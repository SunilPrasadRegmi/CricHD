<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>CricHD Live Cricket Streaming - Watch Live Cricket</title>
	<meta name="description" content="Watch Live Cricket Streaming HD on Crichd. Watch Cricket Live Streaming free. Cricket World Cup 2023 Live Streaming. Tennis, Rugby, Football Live Streaming. Formula 1 or F1 live streaming.">
	<meta name="keywords" content="crichd, crichd live, live cricket, live cricke stream, live cricket streaming, watch live cricket, live cricket streaming hd, cricket world cup, watch cricket online, cricket live, cricket live streaming, tennis, tennis live, football, football live, live football, live football streaming, football live streaming, rugby, rugby live streaming, f1 stream, formula 1 live, formula 1 live streaming, f1 live streaming," />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="https://cssjsimg4.procdncache.com/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="./style.css">
</head>
<body>
    <div class="w3-content" style="max-width: 1500px">
        <header class="w3-panel w3-center w3-opacity" style="padding: 10px 0; background-color: #d32f2f; color: #fff;">
            <a href="https://t.me/guruusr/">
                <img src="./logo2.png" style="height: 90px">
            </a>
        </header>

        <div class="container">
            <h1 class="page-title">Scripted By Guru Sharma</h1>

            <!-- Search Bar -->
            <input type="text" id="channelSearch" placeholder="Search channel by name..." class="search-bar">
            
            <div class="channel-grid">

				<div class="channel-box">
                    <a href="./play.php?c=bbtsp1">
                        <div class="channel-logo" style="background-image: url('./logo/tnt_sports.jfif');"></div>
                        <div class="channel-info">TNT Sports 1</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=bbtsp2">
                        <div class="channel-logo" style="background-image: url('./logo/tnt_sports.jfif');"></div>
                        <div class="channel-info">TNT Sports 2</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=bbtsp3">
                        <div class="channel-logo" style="background-image: url('./logo/tnt_sports.jfif');"></div>
                        <div class="channel-info">TNT Sports 3</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=bbtsp4">
                        <div class="channel-logo" style="background-image: url('./logo/tnt_sports.jfif');"></div>
                        <div class="channel-info">TNT Sports 4</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysme">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports Main Events</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skyscric">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports Cricket</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysfott">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports Football</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysare">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports Arena</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysact">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports Action</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysgol">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports Golf</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysprem">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports Premier League</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysfor1">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports F1</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysmixx">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports MIX</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=skysnews">
                        <div class="channel-logo" style="background-image: url('./logo/sky_sports.png');"></div>
                        <div class="channel-info">Sky Sports News</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=ptvpk">
                        <div class="channel-logo" style="background-image: url('./logo/ptv.jfif');"></div>
                        <div class="channel-info">PTV Sports</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=asports">
                        <div class="channel-logo" style="background-image: url('./logo/a_sports.jfif');"></div>
                        <div class="channel-info">A Sports</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=astrocric">
                        <div class="channel-logo" style="background-image: url('./logo/astro_cricket.png');"></div>
                        <div class="channel-info">Astro Cricket</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=star1in">
                        <div class="channel-logo" style="background-image: url('./logo/star_sports_1.png');"></div>
                        <div class="channel-info">Star Sports 1</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=star2in">
                        <div class="channel-logo" style="background-image: url('./logo/star_sports_2.png');"></div>
                        <div class="channel-info">Star Sports 2</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=star3in">
                        <div class="channel-logo" style="background-image: url('./logo/star_sports_3.jpg');"></div>
                        <div class="channel-info">Star Sports 3</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=ten1endia">
                        <div class="channel-logo" style="background-image: url('./logo/sony_sports_1.png');"></div>
                        <div class="channel-info">Sony Sports Ten 1</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=ten2endia">
                        <div class="channel-logo" style="background-image: url('./logo/sony_sports_2.png');"></div>
                        <div class="channel-info">Sony Sports Ten 2</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=ten3endia">
                        <div class="channel-logo" style="background-image: url('./logo/sony_sports_3.png');"></div>
                        <div class="channel-info">Sony Sports Ten 3</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=sonysixendia">
                        <div class="channel-logo" style="background-image: url('./logo/sony_sports_5.png');"></div>
                        <div class="channel-info">Sony Sports Ten 5</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=willowusa">
                        <div class="channel-logo" style="background-image: url('./logo/willow_sports.jfif');"></div>
                        <div class="channel-info">Willow Sports</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superspcric">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport Cricket</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superlaliga">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport LaLiga</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superpremierleague">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport Premier League</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superspfb">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport Football</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superspaction">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport Action</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=supergs">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport GrandStand</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superspv1">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport Variety 1</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superspv2">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport Variety 2</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superspv3">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport Variety 3</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=superspv4">
                        <div class="channel-logo" style="background-image: url('./logo/super_sport.jpg');"></div>
                        <div class="channel-info">Super Sport Variety 4</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=geosp">
                        <div class="channel-logo" style="background-image: url('./logo/geo_super.png');"></div>
                        <div class="channel-info">Geo Super</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=tsn1ca">
                        <div class="channel-logo" style="background-image: url('./logo/tsn.jpg');"></div>
                        <div class="channel-info">TSN 1</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=tsn2ca">
                        <div class="channel-logo" style="background-image: url('./logo/tsn.jpg');"></div>
                        <div class="channel-info">TSN 2</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=tsn3ca">
                        <div class="channel-logo" style="background-image: url('./logo/tsn.jpg');"></div>
                        <div class="channel-info">TSN 3</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=tsn4ca">
                        <div class="channel-logo" style="background-image: url('./logo/tsn.jpg');"></div>
                        <div class="channel-info">TSN 4</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=tsn5ca">
                        <div class="channel-logo" style="background-image: url('./logo/tsn.jpg');"></div>
                        <div class="channel-info">TSN 5</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=viaplaysp1">
                        <div class="channel-logo" style="background-image: url('./logo/viaplay.jfif');"></div>
                        <div class="channel-info">Viaplay Sports 1</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=viaplaysp2">
                        <div class="channel-logo" style="background-image: url('./logo/viaplay.jfif');"></div>
                        <div class="channel-info">Viaplay Sports 2</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=viaplayextra">
                        <div class="channel-logo" style="background-image: url('./logo/viaplay.jfif');"></div>
                        <div class="channel-info">Viaplay Xtra</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=eurosp1">
                        <div class="channel-logo" style="background-image: url('./logo/eurosport.jpg');"></div>
                        <div class="channel-info">EuroSport 1</div>
                    </a>
                </div>
				
				<div class="channel-box">
                    <a href="./play.php?c=eurosp2">
                        <div class="channel-logo" style="background-image: url('./logo/eurosport.jpg');"></div>
                        <div class="channel-info">EuroSport 2</div>
                    </a>
                </div>
				
                <!-- Add more channel boxes here -->

            </div>
        </div>
    </div>

    <script>
        // JavaScript for channel search
        const channelSearch = document.getElementById('channelSearch');
        const channelBoxes = document.querySelectorAll('.channel-box');

        channelSearch.addEventListener('input', () => {
            const searchTerm = channelSearch.value.toLowerCase();

            channelBoxes.forEach((box) => {
                const channelInfo = box.querySelector('.channel-info').innerText.toLowerCase();
                if (channelInfo.includes(searchTerm)) {
                    box.style.display = 'block';
                } else {
                    box.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
